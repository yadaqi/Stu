#ifndef MASTER_MAIN_H
#define MASTER_MAIN_H

#include "Master_func.h"
#include "tools.h"
extern Tea *Teacher;
int Master_main(void);

#endif//MASTER_MAIN_H
