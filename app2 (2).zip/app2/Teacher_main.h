#ifndef TEACHER_MAIN_H
#define TEACHER_MAIN_H

int Teacher_main(void);
#endif
