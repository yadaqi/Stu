#ifndef STUDENT_MAIN_H
#define STUDENT_MAIN_H

int Student_main(void);
int Teacher_main(void);
#endif//STUDENT_MAIN_H
