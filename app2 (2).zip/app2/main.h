#ifndef MAIN_H
#define MAIN_H
#include "tools.h"

extern Stu *Student;
extern Tea *Teacher;


#endif
